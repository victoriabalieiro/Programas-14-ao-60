/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>
int main() {
int i=1,soma=0; while(i<=100){ if(i%2==0) soma+=i; i++; } printf("%d",soma);
return 0;
}
