/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>
int main() {
int n,i=1; printf("Numero: "); scanf("%d",&n); while(i<=10){ printf("%d x %d = %d\n",n,i,n*i); i++; }
return 0;
}
