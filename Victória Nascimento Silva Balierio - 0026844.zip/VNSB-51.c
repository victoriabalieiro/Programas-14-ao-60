/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>

int main() {
int i=10; do{ printf("%d\n",i); i--; }while(i>=1);
return 0;
}
