/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>

int main() {
int n,soma=0; do{ scanf("%d",&n); soma+=n; }while(n%10!=0); printf("Soma=%d",soma);
return 0;
}
