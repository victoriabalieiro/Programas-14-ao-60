/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>

int main() {
int n; do{ printf("Numero entre 1 e 5: "); scanf("%d",&n); }while(n<1 || n>5);
return 0;
}
