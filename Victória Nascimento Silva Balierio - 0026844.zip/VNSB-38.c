/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>
int main() {
int senha; while(senha!=1234){ printf("Senha: "); scanf("%d",&senha);} printf("Acesso liberado");
return 0;
}
