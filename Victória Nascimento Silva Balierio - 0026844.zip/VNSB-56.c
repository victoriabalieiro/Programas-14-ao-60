/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>

int main() {
int op; scanf("%d",&op); switch(op){ case 1: printf("Combo Hamburguer + Batata + Refri - R$30"); break; case 2: printf("Combo Pizza Brotinho + Refri - R$25"); break; case 3: printf("Combo Salada + Suco - R$22"); break; case 4: printf("Combo Balde de Frango - R$35"); break; default: printf("Opcao invalida"); }
return 0;
}
