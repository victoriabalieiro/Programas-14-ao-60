/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>

int main() {
int n,maior=0; do{ scanf("%d",&n); if(n>maior) maior=n; }while(n>=0); printf("Maior=%d",maior);
return 0;
}
