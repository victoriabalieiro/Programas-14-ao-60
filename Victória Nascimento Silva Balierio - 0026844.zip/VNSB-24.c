/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>

int main() {
int idade;
printf("Digite a idade: ");
scanf("%d",&idade);
if(idade>=16)
 printf("Pode votar");
else
 printf("Nao pode votar");
return 0;
}
