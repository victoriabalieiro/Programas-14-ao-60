/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>

int main() {
float a,b; char op; scanf("%f %c %f",&a,&op,&b); switch(op){ case '+': printf("%.2f",a+b); break; case '-': printf("%.2f",a-b); break; case '*': printf("%.2f",a*b); break; case '/': printf("%.2f",a/b); break; default: printf("Operacao invalida"); }
return 0;
}
