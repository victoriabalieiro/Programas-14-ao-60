/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>
int main() {
int i=1; while(i<=10){ printf("%d\n",i); i++; }
return 0;
}
