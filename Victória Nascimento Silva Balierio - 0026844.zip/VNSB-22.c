/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>

int main() {
int n;
printf("Digite um numero: ");
scanf("%d",&n);
if(n%2==0)
 printf("Par");
else
 printf("Impar");
return 0;
}
