/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>
int main() {
int soma=0; for(int i=1;i<=100;i++) soma+=i; printf("Soma = %d",soma);
return 0;
}
