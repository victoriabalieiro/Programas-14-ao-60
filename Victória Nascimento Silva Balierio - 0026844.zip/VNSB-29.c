/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>
int main() {
for(int i=0;i<=50;i+=2) printf("%d\n",i);
return 0;
}
