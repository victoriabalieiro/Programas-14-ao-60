/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>

int main() {
char op; do{ printf("Deseja sair? (s/n): "); scanf(" %c",&op); }while(op!='s');
return 0;
}
