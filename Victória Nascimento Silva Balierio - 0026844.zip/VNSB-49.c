/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>

int main() {
int senha; do{ printf("Senha: "); scanf("%d",&senha); }while(senha!=1111); printf("Acesso liberado!");
return 0;
}
