/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>

int main() {
int n,i=1; scanf("%d",&n); do{ printf("%d x %d = %d\n",n,i,n*i); i++; }while(i<=10);
return 0;
}
