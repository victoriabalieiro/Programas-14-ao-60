/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>

int main() {
int n; do{ printf("Digite positivo: "); scanf("%d",&n); }while(n<=0);
return 0;
}
