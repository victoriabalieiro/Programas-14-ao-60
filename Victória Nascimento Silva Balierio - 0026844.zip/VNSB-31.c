/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>
int main() {
for(int i=10;i>=1;i--) printf("%d\n",i);
return 0;
}
