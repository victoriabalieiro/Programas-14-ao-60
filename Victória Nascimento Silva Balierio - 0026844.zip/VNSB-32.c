/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>
int main() {
for(int i=1;i<=10;i++) printf("%d^2 = %d\n",i,i*i);
return 0;
}
