/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>

int main() {
int altura;
printf("Digite a altura: ");
scanf("%d",&altura);
if(altura>=140)
 printf("Liberado");
else
 printf("Barrado");
return 0;
}
