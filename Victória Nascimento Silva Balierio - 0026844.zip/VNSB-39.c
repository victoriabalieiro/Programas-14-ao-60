/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>
int main() {
int n=0; while(n<=0){ printf("Digite positivo: "); scanf("%d",&n);}
return 0;
}
