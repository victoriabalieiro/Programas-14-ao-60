/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>
int main() {
int n,i=1,cont=0; while(i<=10){ scanf("%d",&n); if(n%2!=0) cont++; i++; } printf("Impares=%d",cont);
return 0;
}
