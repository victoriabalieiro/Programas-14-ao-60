/* Vict�ria Nascimento Silva Balieiro - RA: 0026844 */

#include <stdio.h>

int main() {
int a,b;
printf("Digite dois numeros: ");
scanf("%d%d",&a,&b);
if(a>b)
 printf("Maior: %d",a);
else
 printf("Maior: %d",b);
return 0;
}
